const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const fs = require('fs');

app.use(express.static(__dirname));

//html読み込み
app.get('/',function(req,res) {
    res.sendFile(__dirname + './index.html');
});

//画像読み込み
app.get('/image', (req, res) => {
    fs.readFile('./default.png', (err, image) => {
      res.type('png');
      res.send(image);
    });
});

//サーバー開く
http.listen(3000,function(){
    console.log('server listening. Port:3000');
});

//Arduinoとのシリアル通信
const SerialPort = require('serialport');
const port = new SerialPort('COM4',{baudRate: 9600});
let parser = new SerialPort.parsers.Readline;
port.pipe(parser);

let reader = require('readline').createInterface({
    input: process.stdin
});

reader.on('line',function(line){
    port.write(new Buffer(line+'\n'));
});

parser.on('data',(data)=>{
	//クライアントのにdataを送信
	io.emit('status',data);
	dataArray = data.split(',');

	//体温、脈拍の平均等を求める
	io.emit('AvgTemp',AvgTemp);
	io.emit('AvgHeat',AvgHeat);
	io.emit('standard',standard);
	/*io.emit('diffTemp',diffTemp);
	io.emit('diffHeat',diffHeat);*/
	io.emit('diff',diff);
	Average();

	//csvファイル書き込み
	date();
	get = time + "," + data;
	//console.log(get);
    testArr.push([get]);
    exportCSV(testArr);
    formatCSV = "";

});

io.on('connection',function(socket){
    console.log('connected');
});

// 配列をcsvで保存するfunction
let formatCSV = '';
let testArr = [];
let time = 0;
let get = 0;

function exportCSV(content){
	for (var i = 0; i < content.length; i++) {
		var value = content[i];

		for (var j = 0; j < value.length; j++) { var innerValue = value[j]===null?'':value[j].toString(); var result = innerValue.replace(/"/g, '""'); if (result.search(/("|,|\n)/g) >= 0)
		if (j > 0)
		formatCSV += ',';
		formatCSV += result;
	  }
	  formatCSV += '\n';
	}
	fs.writeFile('test.csv', formatCSV, 'utf8', function (err) {
	});
  }

//体温、脈拍計算
let AvgTemp = 0;
let AvgHeat = 0;
let loopTime = 0;
let loopHeat = 0;
let addTemp = 0;
let addHeat = 0;
let diffTemp = 0;
let diffHeat = 0;
let ArrayTemp = [];
let ArrayHeat = [];
let addTempSt = 0;
let AvgTempSt = 0;
let standard = 0;
let AvgHeatSt = 0;
let diff = 0;
function Average(){
	//データ取得数
	loopTime += 1;
	//配列にデータを格納していく
	ArrayTemp.push([dataArray[0]]);

	//体温の平均
	//直近10秒前のデータを加算
	if(loopTime > 10){
		addTemp = 0;
		for(let i=1;i <= 10;i++){
			addTemp += Number([ArrayTemp[loopTime-i]]);
		}
		AvgTemp = (addTemp/10).toFixed(2);
	}else{
		addTemp += Number(dataArray[0]);
		AvgTemp = (addTemp/loopTime).toFixed(2);
	}

	//脈拍の平均
	//直近30秒前のデータを加算
	if(loopTime%10 == 0){
		loopHeat += 1;
		ArrayHeat.push([dataArray[1]]);
		if(loopHeat > 3){
			addHeat = 0;
			for(let i=1;i <= 3;i++){
				addHeat += Number([ArrayHeat[loopHeat-i]]);
			}
			AvgHeat = (addHeat/3).toFixed(2);
		}else{
			addHeat += Number(dataArray[1]);
			AvgHeat = (addHeat/loopHeat).toFixed(2);
		}
	}

	//基準点の作成
	/*
	addTempSt += Number([dataArray[0]]);
	if(loopTime == 30){
		AvgTempSt = (addTempSt/30).toFixed(2);
		standard = String(AvgTempSt) + "," +String(AvgHeat);

	//基準点からの体温の変化量
	if(loopTime > 30){
		diffTemp = (dataArray[0] - AvgTempSt).toFixed(2);
		if(loopTime%10 == 0){
			diffHeat = (dataArray[0] - AvgHeatSt).toFixed(2);
		}
		diff = String(diffTemp) + "," +String(diffHeat);
		}
	}
	*/
	//デモ用
	addTempSt += Number([dataArray[0]]);
	if(loopTime == 10){
		AvgTempSt = (addTempSt/10).toFixed(2);
		standard = String(AvgTempSt) + "," +String(AvgHeat);
		AvgHeatSt = AvgHeat;
	}

	if(loopTime > 10){
		diffTemp = (dataArray[0] - AvgTempSt).toFixed(2);
		if(loopTime%10 == 0){
			diffHeat = (dataArray[0] - AvgHeatSt).toFixed(2);
		}
		diff = String(diffTemp) + "," +String(diffHeat);
	}
}

//時刻の取得
function date(){
	let now = new Date();
	let date = now.getDate();
	let Hour = now.getHours();
	let Min = now.getMinutes();
	let Sec = now.getSeconds();
	time = String(date + "/" + Hour + "/" + Min + "/" + Sec);
	return time;
}